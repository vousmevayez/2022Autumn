#include <fstream>
#include <string>
#include <bits/stdc++.h>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

class block
{
public:
    block() : xl(0), yl(0), type(0), w(0), h(0), iterSpace(0), iterTile(0){};
    ~block(){};

    // block(int solid, int h, int w, int xl, int yl) : _rt(nullptr), _lb(nullptr), _tr(nullptr), _bl(nullptr);

    // block *_rt, *_lb, *_bl, *_tr;

    // whether it is solid block
    int solid;
    // 0 for space, 1 for block
    int type;
    int iterSpace, iterTile;
    // int xleft, ybottom, xright, ytop;

    // height, weight, x_lower, y_lower
    int h, w, xl, yl;
};

class corner_stitching
{
public:
    corner_stitching() {}
    ~corner_stitching() {}

    // declaration
    corner_stitching(int xl, int yl);
    void p_f(int xl, int yl);
    void b_c(int type, int xl, int yl, int w, int h);

    // void stitches(block *new_obj);

    // do up side split
    block *uhorizontal(block *obj, block *bk);

    // do down side split
    block *dhorizontal(block *obj, block *bk);

    // do left side split
    block *lvertical(block *obj, block *bk);

    // do right side split
    block *rvertical(block *obj, block *bk);
    void insertion();

    // search neighbor blocks
    void adjacent(block *bk);
};

// setting the outline
struct line
{
    int h, w;
} outline;

// int is(0), it(0), ibk(0);
int is = 0, it = 0, ibk = 0;

// save data
vector<block> space, tile, bks, p_f_;

// compare
bool diff_y(block j, block k)
{
    return j.yl < k.yl;
}

bool diff_t(block j, block k)
{
    return j.type < k.type;
}

// point finding process
void corner_stitching::p_f(int xl, int yl)
{
    block *obj;
    // initialization
    int solid = 0;

    for (int i = 0; i < space.size(); i++)
    {
        obj = &space[i];
        if (yl >= obj->yl && (yl < (obj->yl + obj->h)) && (obj->xl <= xl) && (xl < (obj->xl + obj->w)))
        {
            p_f_.push_back(*obj);
            solid = 1;
            break;
        }
    }
    if (!solid)
    {
        for (int i = 0; i < bks.size(); i++)
        {
            obj = &bks[i];
            if ((obj->yl <= yl) && (yl < (obj->yl + obj->h)) && (obj->xl <= xl) && (xl < obj->xl + obj->w))
            {
                p_f_.push_back(*obj);
                break;
            }
        }
    }
}

// block creating process
void corner_stitching::b_c(int type, int xl, int yl, int w, int h)
{
    block *nobj = new block;

    // type 0 for space, 1 for block
    nobj->type = type;
    nobj->xl = xl;
    nobj->yl = yl;
    nobj->w = w;
    nobj->h = h;

    if (type == 0)
        space.push_back(*nobj);
    else
        bks.push_back(*nobj);
}

// up
block *corner_stitching::uhorizontal(block *obj, block *bk)
{
    block *nobj = new block;

    nobj->type = bk->type;
    nobj->xl = obj->xl;
    nobj->yl = obj->yl;
    nobj->w = obj->w;
    nobj->h = bk->yl + bk->h - obj->yl;

    obj->type = 0;
    obj->h = obj->yl + obj->h - bk->yl - bk->h;
    obj->yl = bk->yl + bk->h;
    space.push_back(*nobj);
}

// down
block *corner_stitching::dhorizontal(block *obj, block *bk)
{
    block *nobj = new block;

    nobj->type = bk->type;
    nobj->xl = obj->xl;
    nobj->yl = bk->yl;
    nobj->w = obj->w;
    nobj->h = obj->yl + obj->h - bk->yl;

    obj->type = 0;
    obj->h = bk->yl - obj->yl;
    space.push_back(*nobj);
}

// left
block *corner_stitching::lvertical(block *obj, block *bk)
{
    block *nobj = new block;

    nobj->type = bk->type;
    nobj->xl = bk->xl;
    nobj->yl = obj->yl;
    nobj->w = obj->xl + obj->w - bk->xl;
    nobj->h = obj->h;

    obj->type = 0;
    obj->w = bk->xl - obj->xl;
    space.push_back(*nobj);
}

// right
block *corner_stitching::rvertical(block *obj, block *bk)
{
    block *nobj = new block;

    nobj->type = bk->type;
    nobj->xl = bk->xl;
    nobj->yl = obj->yl;
    nobj->w = bk->w;
    nobj->h = obj->h;

    obj->type = 0;
    obj->w = obj->w - bk->w;
    obj->xl = bk->xl + bk->w;
    space.push_back(*nobj);
}

// inserting process
void corner_stitching::insertion()
{
    block *obj = &space.front(), *bk = &bks[ibk - 1], *obj_;

    int size = space.size();
    int i = 0;
    while (i < size)
    {
        obj = &space[i];
        if ((obj->xl <= bk->xl) && ((obj->xl + obj->w) >= (bk->xl + bk->w)))
        {
            if (((obj->yl + obj->h) > bk->yl) && ((bk->yl + bk->h) > obj->yl))
            {
                if (((obj->yl + obj->h) > (bk->yl + bk->h)) && ((bk->yl + bk->h) > obj->yl))
                {
                    uhorizontal(obj, bk);
                    obj = &space.back();
                }
                if ((obj->yl < bk->yl) && (bk->yl < (obj->yl + obj->h)))
                {
                    dhorizontal(obj, bk);
                    obj = &space.back();
                }
                if ((obj->xl < bk->xl) && (bk->xl < (obj->xl + obj->w)))
                {
                    lvertical(obj, bk);
                    obj = &space.back();
                }
                if (((obj->xl + obj->w) > (bk->xl + bk->w)) && ((bk->xl + bk->w) > obj->xl))
                {
                    rvertical(obj, bk);
                    obj = &space.back();
                }

                // get block outside the vector
                if (obj->type != 0)
                    space.pop_back();
                else if ((obj->xl == bk->xl) && (obj->w == bk->w) && (obj->yl >= bk->yl) && ((obj->yl + obj->h) <= (bk->yl + bk->h)))
                {
                    space.erase(space.begin() + i);
                    i--;
                    size--;
                }
            }
        }
        i++;
    }
    if (!space.empty())
    {
        // sort y value
        sort(space.begin(), space.end(), diff_y);
        for (int i = 0; i < space.size() - 1; i++)
        {
            obj = &space[i];
            for (int j = i + 1; j < space.size(); j++)
            {
                obj_ = &space[j];
                if ((obj->w == obj_->w) && (obj->xl == obj_->xl) && (obj->yl + obj->h == obj_->yl))
                {
                    obj->h += obj_->h;
                    space.erase(space.begin() + j);
                }
            }
        }
    }
}

// finding neighbor blocks process
void corner_stitching::adjacent(block *bk)
{
    block *obj, *nobj;
    is = 0, it = 0;

    if (!space.empty())
    {
        for (int i = 0; i < space.size(); i++)
        {
            obj = &space[i];
            if (((bk->yl + bk->h) == obj->yl) || (bk->yl == (obj->yl + obj->h)))
            {
                if ((obj->xl < bk->xl) && ((obj->xl + obj->w) > bk->xl))
                    is++;
                else if ((obj->xl >= bk->xl) && ((obj->xl + obj->w) <= (bk->xl + bk->w)))
                    is++;
                else if ((obj->xl < (bk->xl + bk->w)) && ((bk->xl + bk->w) < (obj->xl + obj->w)))
                    is++;
            }
            if ((bk->xl == obj->xl + obj->w) || ((bk->xl + bk->w) == obj->xl))
            {
                if (((obj->yl + obj->h) > (bk->yl + bk->h)) && (obj->yl < (bk->yl + bk->h)))
                    is++;
                else if (((bk->yl + bk->h) >= (obj->yl + obj->h)) && (obj->yl >= bk->yl))
                    is++;
                else if ((bk->yl < (obj->yl + obj->h)) && (obj->yl < bk->yl))
                    is++;
            }
        }
    }

    for (int i = 0; i < bks.size(); i++)
    {
        obj = &bks[i];
        if (((bk->yl + bk->h) == obj->yl) || (bk->yl == (obj->yl + obj->h)))
        {
            if ((obj->xl < bk->xl) && ((obj->xl + obj->w) > bk->xl))
                it++;
            else if ((obj->xl >= bk->xl) && ((obj->xl + obj->w) <= (bk->xl + bk->w)))
                it++;
            else if ((obj->xl < (bk->xl + bk->w)) && ((bk->xl + bk->w) < (obj->xl + obj->w)))
                it++;
        }
    }

    for (int i = 0; i < bks.size(); i++)
    {
        obj = &bks[i];
        if ((bk->xl == (obj->xl + obj->w)) || ((bk->xl + bk->w) == obj->xl))
        {
            if (((obj->yl + obj->h) > (bk->yl + bk->h)) && (obj->yl < (bk->yl + bk->h)))
                it++;
            else if (((bk->yl + bk->h) >= (obj->yl + obj->h)) && (obj->yl >= bk->yl))
                it++;
            else if ((bk->yl < (obj->yl + obj->h)) && (obj->yl < bk->yl))
                it++;
        }
    }
    // update data
    nobj = bk;
    nobj->iterSpace = is;
    nobj->iterTile = it;
    // tile
    tile.push_back(*nobj);
}

int main(int argc, char **argv)
{
    ifstream fin(argv[1]);
    ofstream fout(argv[2]);
    /*
    string line;
    getline(fin, line);
    stringstream ss(line);
    */
    fin >> outline.w >> outline.h;

    string s;
    int xp, yp, b_type, xb, yb, wb, hb;

    // corner_stitching b_c(0, 0, 0, outline.w, outline.h);
    corner_stitching corner;

    corner.b_c(0, 0, 0, outline.w, outline.h);

    while (fin >> s)
    {
        // ss.str(fout);
        // ss.clear();
        // string temp;
        // ss >> temp;
        if (s == "P")
        {
            fin >> xp >> yp;
            corner.p_f(xp, yp);
        }
        else
        {
            b_type = stoi(s);
            fin >> xb >> yb >> wb >> hb;
            corner.b_c(b_type, xb, yb, wb, hb);
            ibk++;
            // void corner_stitching::insertion(block *bk);
            corner.insertion();
        }
    }

    int iterations = bks.size();
    for (int i = 0; i < iterations; i++)
    {
        // void corner_stitching::adjacent(block *bk);
        corner.adjacent(&bks[i]);
    }

    // sort type value
    sort(tile.begin(), tile.end(), diff_t);

    // output file
    fout << bks.size() + space.size() << endl;
    iterations = tile.size();
    for (int i = 0; i < iterations; i++)
    {
        fout << tile[i].type << " " << tile[i].iterTile
             << " " << tile[i].iterSpace << endl;
    }

    iterations = p_f_.size();
    for (int i = 0; i < iterations; i++)
    {
        fout << p_f_[i].xl << " " << p_f_[i].yl << endl;
    }

    fin.close();
    fout.close();
    return 0;
}
