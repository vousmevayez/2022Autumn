#include "bst.cpp"

void InitBlock(ifstream &finBlock);
void InitNet(ifstream &finNet);
void OutputFile(ofstream &fout, double tookTime, double &alpha);

int main(int argc, char *argv[])
{
    double alpha;
    alpha = stod(argv[1]);

    ifstream finBlock(argv[2]);
    ifstream finNet(argv[3]);
    ofstream fout(argv[4]);

    // cout << "bug" << endl;
    InitBlock(finBlock);
    // cout << "bug0" <<endl;
    InitNet(finNet);
    // cout << "net" << endl;
    // BStarTree BST;
    clock_t start, end;
    start = clock();

    // double
    finalCost = 2e9;
    int SA_time = 30;
    while (SA_time--)
    {
        initBST();
        SA();
        finalResult();
    }
    // cout << "bug2" << endl;
    end = clock();
    double tookTime = double(end - start) / double(CLOCKS_PER_SEC);
    cout << "Time taken by floorplanning is " << fixed << setprecision(5)
         << tookTime << " secends." << endl;
    // cout << "bug3" << endl;
    OutputFile(fout, tookTime, alpha);  
    //<< fixed << setprecision(1) 
    // cout << "bug4" << endl;
    finBlock.close();
    finNet.close();
    fout.close();
    return 0;
}

void InitBlock(ifstream &finBlock)
{
    string info;
    finBlock >> info >> outlineX >> outlineY;
    finBlock >> info >> numBlock >> info >> numTerminal;
    // cout << "bug1" << endl;
    for (int i = 1; i <= numBlock; i++)
    {
        string s;
        finBlock >> s >> dataBlock[i].first >> dataBlock[i].second;
        // cout << s << endl;
        blockName[i] = s;
        mapData[s] = i;
        totalArea += dataBlock[i].first * dataBlock[i].second;
        // cout << "bk:" << i << dataBlock[i].first  << dataBlock[i].second << endl;
    }
    // cout << "bug5" << endl;
    for (int i = numBlock + 1; i <= numBlock + numTerminal; i++)
    {
        string s;
        finBlock >> s >> info >> dataBlock[i].first >> dataBlock[i].second;
        x[i] = urX[i] = dataBlock[i].first;
        y[i] = urY[i] = dataBlock[i].second;
        mapData[s] = i;
        // cout << "terminal:" << i << dataBlock[i].first  << dataBlock[i].second << endl;
    }
    // cout << "bug6" << endl;
    optimArea = INT_MAX;
    // cout << "bug7" << endl;
}

void InitNet(ifstream &finNet)
{
    string info;
    finNet >> info >> numNet;
    for (i = 0; i < numNet; i++)
    {
        finNet >> info;
        int k;
        finNet >> k;
        net.push_back({});
        while (k--)
        {
            string s;
            finNet >> s;
            net.back().push_back(mapData[s]);
            // cout << "net:" << i << " "<< k  << " "<< s << endl;
        }
    }
}

void OutputFile(ofstream &fout, double tookTime, double &alpha)
{
    fout << int(alpha * (double)finalArea + (1 - alpha) * (double)finalWire) << endl;
    fout << finalWire << endl;
    fout << finalArea << endl;
    int Final_x = 0, Final_y = 0;
    for (i = 1; i < numBlock + 1; i++)
    {
        Final_x = max(Final_x, finalUrX[i]);
        Final_y = max(Final_y, finalUrY[i]);
    }
    fout << Final_x << ' ' << Final_y << endl;
    fout << fixed << tookTime << endl;
    for (i = 1; i < numBlock + 1; i++)
    {
        fout << blockName[i] << ' ' << finalX[i] << ' ' << finalY[i] << ' ' << finalUrX[i] << ' ' << finalUrY[i] << endl;
    }
}