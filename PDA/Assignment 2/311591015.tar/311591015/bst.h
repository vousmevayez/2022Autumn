#ifndef BSTARTREE_H
#define BSTARTREE_H

#include <bits/stdc++.h>
#include <vector>
#include <map>
#include <string>

using namespace std;
#define N 500

int outlineX, outlineY;
int numBlock, numTerminal, numNet;
int root;
int i, j, k;
int H, W;
int x[N], urX[N], y[N], urY[N];
int b[N], p[N];
int finalX[N], finalUrX[N], finalY[N], finalUrY[N];
int bpa[N], bls[N], brs[N], bx[N], brX[N], by[N], brY[N], optimRoot;
int ls[N], rs[N], pa[N];
int optimArea, totalArea, finalArea;
int optimWire, finalWire, hpwl;
int optimCost;
double finalCost; //alpha, 
pair<int, int> dataBlock[N];
pair<int, int> optimDataBlock[N];
map<string, int> mapData;
vector<vector<int>> net;
string blockName[N];

// class BStarTree
// {
// public:
int getArea(int &x, int &y);
int getWire();
void infoBlock(int current, int old);
void initBST();
void dfs(int current, int old);
bool infoUpdate();
void removeNode(int x);
void concatNode(int current, int old);
void swap2(int n1, int n2);
void swap1(int n1, int n2);
void SA();
void finalResult();

// private:
double T = 5000000;
double r = 0.5;
// };
#endif